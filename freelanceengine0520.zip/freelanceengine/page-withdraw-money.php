<?php
/**
 * Template Name: My Project
 */

if ( ! is_user_logged_in() ) {
    wp_redirect( et_get_page_link( 'login', array( 'ae_redirect_url' => get_permalink( $post->ID ) ) ) );
}

get_header();
global $wpdb, $wp_query, $ae_post_factory, $post, $current_user, $user_ID;
$user_role = ae_user_role( $user_ID );
define( 'NO_RESULT', __( '<span class="project-no-results">There are no activities yet.</span>', ET_DOMAIN ) );
$currency = ae_get_option( 'currency', array( 'align' => 'left', 'code' => 'USD', 'icon' => '$' ) );
?>
    <div class="fre-page-wrapper">
        <div class="fre-page-title">
            <div class="container">
                <h2><?php the_title(); ?></h2>
            </div>
        </div>
        <div class="fre-page-section">
            <div class="container">
                <div class="my-work-employer-wrap">
                    <ul class="fre-tabs nav-tabs-my-work">
                        <li class="active"><a data-toggle="tab"
                            href="#require-freelancers-tab"><span><?php _e( 'Freelancers', ET_DOMAIN ); ?></span></a>
                        </li>
                        <li class="next"><a data-toggle="tab"
                            href="#require-employers-tab"><span><?php _e( 'Employers', ET_DOMAIN ); ?></span></a>
                        </li>
                    </ul>
                    <div class="fre-tab-content">
                        <div id="require-freelancers-tab" class="withdraw-require-freelancer-tab fre-panel-tab active">
                            <div class="fre-work-project-box">
                                <div class="work-project-filter">
                                    <form>
                                        <div class="row">
                                            <div class="col-md-8 col-sm-6 col-xs-12">
                                                <div class="fre-input-field">
                                                    <label class="fre-field-title"><?php _e( 'Keyword', ET_DOMAIN ); ?></label>
                                                    <input type="text" class="search" name="s"
                                                           placeholder="<?php _e( 'Search freelancers by keywords', ET_DOMAIN ); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-4 col-sm-6 col-xs-12">
                                                <div class="fre-input-field">
                                                    <label class="fre-field-title"><?php _e( 'Filter', ET_DOMAIN ); ?></label>
                                                    <select class="fre-chosen-single" name="withdraw_current_status">
                                                        <option value=""><?php _e( 'All Status', ET_DOMAIN ); ?></option>
                                                        <option value="pending"><?php _e( 'Pending', ET_DOMAIN ); ?></option>
                                                        <option value="draft"><?php _e( 'Completed', ET_DOMAIN ); ?></option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <a class="clear-filter work-project-filter-clear secondary-color"
                                               href=""><?php _e( 'Clear all filters', ET_DOMAIN ); ?></a>
                                    </form>
                                </div>
                            </div>
                            <div class="fre-work-project-box">
                                <div class="current-freelance-project">
                                    <div class="fre-table">
                                        <div class="fre-table-head">
                                            <div class="fre-table-col withdraw-username-col"><?php _e( 'User Name', ET_DOMAIN ); ?></div>
                                            <div class="fre-table-col withdraw-alipay-col"><?php _e( 'Alypay number', ET_DOMAIN ); ?></div>
                                            <div class="fre-table-col withdraw-momey-col"><?php _e( 'Available money', ET_DOMAIN ); ?></div>
                                            <div class="fre-table-col withdraw-action-col"><?php _e( 'Action', ET_DOMAIN ); ?></div>
                                        </div>
                                        <div class="withdraw-require-freelancer-table-rows" style="display: table-row-group;">
                                            <?php
                                                $freelancer_args = array(
                                                    'post_type'=> 'fre_credit_withdraw',
                                                    'post_status'=> array( 'pending', 'draft' ),
                                                    'meta_query' => array(
                                                        array(
                                                            'key' => 'user_type',
                                                            'value' => 'freelancer',
                                                            'compare' => '='
                                                        )
                                                    ),
                                                    'suppress_filters' => true,
                                                    'orderby'          => 'date',
                                                    'order'            => 'DESC',
                                                );

                                                $freelancer_query = new WP_Query($freelancer_args);
                                                $freelancer_post_data = array();

                                                if( $freelancer_query->have_posts() ) {
                                                while( $freelancer_query->have_posts() ) {
                                                    $freelancer_query->the_post();
                                                    $alipay_number = get_post_meta($post->ID, 'alipay_number', true);
                                                    $currency = get_post_meta($post->ID, 'currency', true);
                                                    $amount = get_post_meta($post->ID, 'amount', true);
                                                    $user_name = get_post_meta($post->ID, 'user_name', true);
                                                    $freelancer_post_data[] = array( 'user_name' => $user_name, 'amount' => $amount, 'alipay_number' => $alipay_number, 'usr_id' => $post->post_author );
                                                    $status = $post->post_status;
                                                    ?>
                                                        <div class="fre-table-row">
                                                            <div class="fre-table-col withdraw-username-col">
                                                                <?php
                                                                    echo $user_name;
                                                                ?>
                                                            </div>
                                                            <div class="fre-table-col withdraw-alipay-col"><?php echo $alipay_number; ?>
                                                            </div>
                                                             <div class="fre-table-col withdraw-momey-col"><?php 
                                                                   echo ($currency->sign).$amount; ?>
                                                            </div>
                                                            <div class="fre-table-col project-action-col">
                                                                <?php if ($status == 'pending'){ ?>
                                                                    <a class="freelancer-withdraw-action" data-action="withdraw" data-confirm-id="<?php echo $post->ID; ?>"><?php echo __( 'Withdraw', ET_DOMAIN ) ?>
                                                                    </a>
                                                                <?php } 
                                                                else { ?>
                                                                    <a class="withdraw-delete-action" data-action="withdraw-delete" data-confirm-id="<?php echo $post->ID; ?>"><?php echo __( 'delete', ET_DOMAIN ) ?>
                                                                    </a>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                <?php } ?>
                                                <script type="data/json" id="withdraw_require_freelancers_post_data"><?php echo json_encode( $freelancer_post_data ); ?></script>
                                                <?php } else {
                                                    $no_result_current = NO_RESULT;
                                                }
                                                ?>
                                        </div> 
                                    </div>
                                </div>
                                    <?php
                                        if ( $no_result_current != '' ) {
                                            echo $no_result_current;
                                        }
                                    ?>
                            </div>
                            <div class="fre-paginations paginations-wrapper">
                                <div class="paginations">
                                    <?php
                                    ae_pagination( $freelancer_query, get_query_var( 'paged' ), 'page' ); ?>
                                </div>
                            </div>
                            <?php
                                wp_reset_postdata();
                                wp_reset_query();
                            ?>
                        </div>
                        <div id="require-employers-tab" class="withdraw-require-employer-tab fre-panel-tab">
                            <div class="fre-work-project-box">
                                <div class="work-project-filter">
                                    <form>
                                        <div class="row">
                                            <div class="col-md-8 col-sm-6 col-xs-12">
                                                <div class="fre-input-field">
                                                    <label class="fre-field-title"><?php _e( 'Keyword', ET_DOMAIN ); ?></label>
                                                    <input type="text" class="search" name="s"
                                                           placeholder="<?php _e( 'Search employers by keywords', ET_DOMAIN ); ?>">
                                                </div>
                                            </div>
                                            <!-- <div class="col-md-4 col-sm-6 col-xs-12">
                                                <div class="fre-input-field">
                                                    <label class="fre-field-title"><?php _e( 'Filter', ET_DOMAIN ); ?></label>
                                                    <select class="fre-chosen-single" name="withdraw_current_status">
                                                        <option value=""><?php _e( 'All Status', ET_DOMAIN ); ?></option>
                                                        <option value="Pending"><?php _e( 'Pending', ET_DOMAIN ); ?></option>
                                                        <option value="Completed"><?php _e( 'Completed', ET_DOMAIN ); ?></option>
                                                    </select>
                                                </div>
                                            </div> -->
                                        </div>
                                        <a class="clear-filter work-project-filter-clear secondary-color"
                                               href=""><?php _e( 'Clear all filters', ET_DOMAIN ); ?></a>
                                    </form>
                                </div>
                            </div>
                            <div class="fre-work-project-box">
                                <div class="current-employer-project">
                                    <div class="fre-table">
                                        <div class="fre-table-head">
                                            <div class="fre-table-col withdraw-username-col"><?php _e( 'User Name', ET_DOMAIN ); ?></div>
                                            <div class="fre-table-col withdraw-alipay-col"><?php _e( 'Alypay number', ET_DOMAIN ); ?></div>
                                            <div class="fre-table-col withdraw-momey-col"><?php _e( 'Available money', ET_DOMAIN ); ?></div>
                                            <div class="fre-table-col withdraw-action-col"><?php _e( 'issue', ET_DOMAIN ); ?></div>
                                        </div>
                                        <div class="withdraw-require-employer-table-rows fre-current-table-rows" style="display: table-row-group;">
                                            <?php
                                                $employer_args = array(
                                                    'post_type'=> 'fre_credit_contact',
                                                    'post_status'=> 'publish',                                                   
                                                    'orderby'          => 'date',
                                                    'suppress_filters' => true,
                                                    'orderby'          => 'date',
                                                    'order'            => 'DESC'
                                                );                                                
                                                $no_result_current = '';
                                                $employer_query = new WP_Query($employer_args);
                                                $employer_post_data = array();

                                                if( $employer_query->have_posts() ) {
                                                while( $employer_query->have_posts() ) {
                                                    $employer_query->the_post();
                                                    $user_id = $post->post_author;
                                                    // $user = get_userdata( $user_id ); 
                                                    // $user_name = $user->user_nicename;
                                                    $user_name = get_post_meta($post->ID, 'user_name', true);
                                                    $phone_number = get_user_meta($user_id, 'phone_number', true);
                                                    $wechat_number = get_user_meta($user_id, 'wechat_number', true);
                                                    $issue = $post->post_content;
                                                    $employer_post_data[] = array( 'user_name' => $user_name, 'phone_number' => $phone_number, 'wechat_number' => $wechat_number, 'issue' => $issue );
                                                    ?>
                                                        <div class="fre-table-row">
                                                            <div class="fre-table-col withdraw-username-col">
                                                                <?php
                                                                    echo $user_name;
                                                                ?>
                                                            </div>
                                                            <div class="fre-table-col withdraw-alipay-col"><?php echo $phone_number; ?>
                                                            </div>
                                                             <div class="fre-table-col withdraw-momey-col"><?php 
                                                                   echo $wechat_number;  ?>
                                                            </div>
                                                            <div class="fre-table-col withdraw-issue-col">
                                                                   <?php echo $issue; ?>
                                                            </div>
                                                        </div>
                                                <?php } ?>
                                                <script type="data/json" id="withdraw_require_employers_post_data"><?php echo json_encode( $employer_post_data ); ?></script>
                                                <?php } else {
                                                    $no_result_current = NO_RESULT;
                                                }
                                                ?>
                                        </div> 
                                    </div>
                                </div>
                                    <?php
                                        if ( $no_result_current != '' ) {
                                            echo $no_result_current;
                                        }
                                    ?>
                            </div>
                            <div class="fre-paginations paginations-wrapper">
                                <div class="paginations">
                                    <?php
                                    ae_pagination( $employer_query, get_query_var( 'paged' ), 'page' ); ?>
                                </div>
                            </div>
                            <?php
                                wp_reset_postdata();
                                wp_reset_query();
                            ?>
                        </div>
                    </div>    
                </div>
            </div>
        </div>
    </div>   
<?php get_footer(); ?>