(function ($, Views, Models, Collections) {

    //Freelancer Current tab
    var FreelancerCurrentProjectTab = $('#generate-cdkey');
    var $freelancer_current = $('.freelancer-current-project-tab');
    var generatecdkeybtn = $('#generate-cdkey');
    var cdkey-display = $('#cdkey-display');
    Models.FreelancerCurrentProject = Backbone.Model.extend();
    Models.generatecdkeybtn = Backbone.Model.extend();

    
    //Modal Delete Project
    // Views.Modal_Delete_Project = AE.Views.Modal_Box.extend({
    //     el: '#modal_delete_project',
    //     events: {
    //         'submit form.form-delete-project': 'deleteProject'
    //     },
    //     initialize: function () {
    //         AE.Views.Modal_Box.prototype.initialize.apply(this, arguments);
    //         this.blockUi = new Views.BlockUi();
    //     },
    //     deleteProject: function (event) {
    //         event.preventDefault();
    //         var view = this,
    //             $target = $(event.currentTarget),
    //             project_id = this.$('#project-id').val();
    //         $.ajax({
    //             url: ae_globals.ajaxURL,
    //             type: 'post',
    //             data: {
    //                 ID: project_id,
    //                 action: 'ae-project-action',
    //                 method: 'delete'
    //             },
    //             beforeSend: function () {
    //                 view.blockUi.block($target);
    //             },
    //             success: function (res) {
    //                 if (res.success) {
    //                     $target.closest('.info-bidding').remove();
    //                     AE.pubsub.trigger('ae:notification', {
    //                         msg: res.msg,
    //                         notice_type: 'success'
    //                     });
    //                 } else {
    //                     AE.pubsub.trigger('ae:notification', {
    //                         msg: res.msg,
    //                         notice_type: 'error'
    //                     });
    //                 }
    //                 location.reload();
    //             }
    //         });
    //     }
    // });

})(jQuery, AE.Views, AE.Models, AE.Collections);