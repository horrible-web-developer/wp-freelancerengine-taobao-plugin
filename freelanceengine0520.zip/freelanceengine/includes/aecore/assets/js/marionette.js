var Marionette = function(e, t, n) {
    "use strict";

    function s(e, t) {
        var n = new Error(e);
        n.name = t || "Error";
        throw n
    }(function(e, t) {
        "use strict";
        var n = e.ChildViewContainer;
        e.ChildViewContainer = function(e, t) {
            var n = function(e) {
                this._views = {};
                this._indexByModel = {};
                this._indexByCustom = {};
                this._updateLength();
                t.each(e, this.add, this)
            };
            t.extend(n.prototype, {
                add: function(e, t) {
                    var n = e.cid;
                    this._views[n] = e;
                    if (e.model) {
                        this._indexByModel[e.model.cid] = n
                    }
                    if (t) {
                        this._indexByCustom[t] = n
                    }
                    this._updateLength();
                    return this
                },
                findByModel: function(e) {
                    return this.findByModelCid(e.cid)
                },
                findByModelCid: function(e) {
                    var t = this._indexByModel[e];
                    return this.findByCid(t)
                },
                findByCustom: function(e) {
                    var t = this._indexByCustom[e];
                    return this.findByCid(t)
                },
                findByIndex: function(e) {
                    return t.values(this._views)[e]
                },
                findByCid: function(e) {
                    return this._views[e]
                },
                remove: function(e) {
                    var n = e.cid;
                    if (e.model) {
                        delete this._indexByModel[e.model.cid]
                    }
                    t.any(this._indexByCustom, function(e, t) {
                        if (e === n) {
                            delete this._indexByCustom[t];
                            return true
                        }
                    }, this);
                    delete this._views[n];
                    this._updateLength();
                    return this
                },
                call: function(e) {
                    this.apply(e, t.tail(arguments))
                },
                apply: function(e, n) {
                    t.each(this._views, function(r) {
                        if (t.isFunction(r[e])) {
                            r[e].apply(r, n || [])
                        }
                    })
                },
                _updateLength: function() {
                    this.length = t.size(this._views)
                }
            });
            var r = ["forEach", "each", "map", "find", "detect", "filter", "select", "reject", "every", "all", "some", "any", "include", "contains", "invoke", "toArray", "first", "initial", "rest", "last", "without", "isEmpty", "pluck"];
            t.each(r, function(e) {
                n.prototype[e] = function() {
                    var n = t.values(this._views);
                    var r = [n].concat(t.toArray(arguments));
                    return t[e].apply(t, r)
                }
            });
            return n
        }(e, t);
        e.ChildViewContainer.VERSION = "0.1.4";
        e.ChildViewContainer.noConflict = function() {
            e.ChildViewContainer = n;
            return this
        };
        return e.ChildViewContainer
    })(t, n);
    (function(e, t) {
        "use strict";
        var n = e.Wreqr;
        var r = e.Wreqr = {};
        e.Wreqr.VERSION = "1.3.1";
        e.Wreqr.noConflict = function() {
            e.Wreqr = n;
            return this
        };
        r.Handlers = function(e, t) {
            "use strict";
            var n = function(e) {
                this.options = e;
                this._wreqrHandlers = {};
                if (t.isFunction(this.initialize)) {
                    this.initialize(e)
                }
            };
            n.extend = e.Model.extend;
            t.extend(n.prototype, e.Events, {
                setHandlers: function(e) {
                    t.each(e, function(e, n) {
                        var r = null;
                        if (t.isObject(e) && !t.isFunction(e)) {
                            r = e.context;
                            e = e.callback
                        }
                        this.setHandler(n, e, r)
                    }, this)
                },
                setHandler: function(e, t, n) {
                    var r = {
                        callback: t,
                        context: n
                    };
                    this._wreqrHandlers[e] = r;
                    this.trigger("handler:add", e, t, n)
                },
                hasHandler: function(e) {
                    return !!this._wreqrHandlers[e]
                },
                getHandler: function(e) {
                    var t = this._wreqrHandlers[e];
                    if (!t) {
                        return
                    }
                    return function() {
                        var e = Array.prototype.slice.apply(arguments);
                        return t.callback.apply(t.context, e)
                    }
                },
                removeHandler: function(e) {
                    delete this._wreqrHandlers[e]
                },
                removeAllHandlers: function() {
                    this._wreqrHandlers = {}
                }
            });
            return n
        }(e, t);
        r.CommandStorage = function() {
            "use strict";
            var n = function(e) {
                this.options = e;
                this._commands = {};
                if (t.isFunction(this.initialize)) {
                    this.initialize(e)
                }
            };
            t.extend(n.prototype, e.Events, {
                getCommands: function(e) {
                    var t = this._commands[e];
                    if (!t) {
                        t = {
                            command: e,
                            instances: []
                        };
                        this._commands[e] = t
                    }
                    return t
                },
                addCommand: function(e, t) {
                    var n = this.getCommands(e);
                    n.instances.push(t)
                },
                clearCommands: function(e) {
                    var t = this.getCommands(e);
                    t.instances = []
                }
            });
            return n
        }();
        r.Commands = function(e) {
            "use strict";
            return e.Handlers.extend({
                storageType: e.CommandStorage,
                constructor: function(t) {
                    this.options = t || {};
                    this._initializeStorage(this.options);
                    this.on("handler:add", this._executeCommands, this);
                    var n = Array.prototype.slice.call(arguments);
                    e.Handlers.prototype.constructor.apply(this, n)
                },
                execute: function(e, t) {
                    e = arguments[0];
                    t = Array.prototype.slice.call(arguments, 1);
                    if (this.hasHandler(e)) {
                        this.getHandler(e).apply(this, t)
                    } else {
                        this.storage.addCommand(e, t)
                    }
                },
                _executeCommands: function(e, n, r) {
                    var i = this.storage.getCommands(e);
                    t.each(i.instances, function(e) {
                        n.apply(r, e)
                    });
                    this.storage.clearCommands(e)
                },
                _initializeStorage: function(e) {
                    var n;
                    var r = e.storageType || this.storageType;
                    if (t.isFunction(r)) {
                        n = new r
                    } else {
                        n = r
                    }
                    this.storage = n
                }
            })
        }(r);
        r.RequestResponse = function(e) {
            "use strict";
            return e.Handlers.extend({
                request: function() {
                    var e = arguments[0];
                    var t = Array.prototype.slice.call(arguments, 1);
                    if (this.hasHandler(e)) {
                        return this.getHandler(e).apply(this, t)
                    }
                }
            })
        }(r);
        r.EventAggregator = function(e, t) {
            "use strict";
            var n = function() {};
            n.extend = e.Model.extend;
            t.extend(n.prototype, e.Events);
            return n
        }(e, t);
        r.Channel = function(n) {
            "use strict";
            var r = function(t) {
                this.vent = new e.Wreqr.EventAggregator;
                this.reqres = new e.Wreqr.RequestResponse;
                this.commands = new e.Wreqr.Commands;
                this.channelName = t
            };
            t.extend(r.prototype, {
                reset: function() {
                    this.vent.off();
                    this.vent.stopListening();
                    this.reqres.removeAllHandlers();
                    this.commands.removeAllHandlers();
                    return this
                },
                connectEvents: function(e, t) {
                    this._connect("vent", e, t);
                    return this
                },
                connectCommands: function(e, t) {
                    this._connect("commands", e, t);
                    return this
                },
                connectRequests: function(e, t) {
                    this._connect("reqres", e, t);
                    return this
                },
                _connect: function(e, n, r) {
                    if (!n) {
                        return
                    }
                    r = r || this;
                    var i = e === "vent" ? "on" : "setHandler";
                    t.each(n, function(n, s) {
                        this[e][i](s, t.bind(n, r))
                    }, this)
                }
            });
            return r
        }(r);
        r.radio = function(e) {
            "use strict";
            var n = function() {
                this._channels = {};
                this.vent = {};
                this.commands = {};
                this.reqres = {};
                this._proxyMethods()
            };
            t.extend(n.prototype, {
                channel: function(e) {
                    if (!e) {
                        throw new Error("Channel must receive a name")
                    }
                    return this._getChannel(e)
                },
                _getChannel: function(t) {
                    var n = this._channels[t];
                    if (!n) {
                        n = new e.Channel(t);
                        this._channels[t] = n
                    }
                    return n
                },
                _proxyMethods: function() {
                    t.each(["vent", "commands", "reqres"], function(e) {
                        t.each(r[e], function(t) {
                            this[e][t] = i(this, e, t)
                        }, this)
                    }, this)
                }
            });
            var r = {
                vent: ["on", "off", "trigger", "once", "stopListening", "listenTo", "listenToOnce"],
                commands: ["execute", "setHandler", "setHandlers", "removeHandler", "removeAllHandlers"],
                reqres: ["request", "setHandler", "setHandlers", "removeHandler", "removeAllHandlers"]
            };
            var i = function(e, t, n) {
                return function(r) {
                    var i = e._getChannel(r)[t];
                    var s = Array.prototype.slice.call(arguments, 1);
                    return i[n].apply(i, s)
                }
            };
            return new n
        }(r);
        return e.Wreqr
    })(t, n);
    var r = {};
    t.Marionette = r;
    r.$ = t.$;
    var i = Array.prototype.slice;
    r.extend = t.Model.extend;
    r.getOption = function(e, t) {
        if (!e || !t) {
            return
        }
        var n;
        if (e.options && t in e.options && e.options[t] !== undefined) {
            n = e.options[t]
        } else {
            n = e[t]
        }
        return n
    };
    r.normalizeMethods = function(e) {
        var t = {},
            r;
        n.each(e, function(e, i) {
            r = e;
            if (!n.isFunction(r)) {
                r = this[r]
            }
            if (!r) {
                return
            }
            t[i] = r
        }, this);
        return t
    };
    r.normalizeUIKeys = function(e, t) {
        if (typeof e === "undefined") {
            return
        }
        n.each(n.keys(e), function(n) {
            var r = /@ui.[a-zA-Z_$0-9]*/g;
            if (n.match(r)) {
                e[n.replace(r, function(e) {
                    return t[e.slice(4)]
                })] = e[n];
                delete e[n]
            }
        });
        return e
    };
    r.actAsCollection = function(e, t) {
        var r = ["forEach", "each", "map", "find", "detect", "filter", "select", "reject", "every", "all", "some", "any", "include", "contains", "invoke", "toArray", "first", "initial", "rest", "last", "without", "isEmpty", "pluck"];
        n.each(r, function(r) {
            e[r] = function() {
                var e = n.values(n.result(this, t));
                var i = [e].concat(n.toArray(arguments));
                return n[r].apply(n, i)
            }
        })
    };
    r.triggerMethod = function() {
        function t(e, t, n) {
            return n.toUpperCase()
        }
        var e = /(^|:)(\w)/gi;
        var r = function(r) {
            var i = "on" + r.replace(e, t);
            var s = this[i];
            if (n.isFunction(this.trigger)) {
                this.trigger.apply(this, arguments)
            }
            if (n.isFunction(s)) {
                return s.apply(this, n.tail(arguments))
            }
        };
        return r
    }();
    r.MonitorDOMRefresh = function(e) {
        function t(e) {
            e._isShown = true;
            i(e)
        }

        function r(e) {
            e._isRendered = true;
            i(e)
        }

        function i(e) {
            if (e._isShown && e._isRendered && s(e)) {
                if (n.isFunction(e.triggerMethod)) {
                    e.triggerMethod("dom:refresh")
                }
            }
        }

        function s(t) {
            return e.contains(t.el)
        }
        return function(e) {
            e.listenTo(e, "show", function() {
                t(e)
            });
            e.listenTo(e, "render", function() {
                r(e)
            })
        }
    }(document.documentElement);
    (function(e) {
        "use strict";

        function t(e, t, r, i) {
            var o = i.split(/\s+/);
            n.each(o, function(n) {
                var i = e[n];
                if (!i) {
                    s("Method '" + n + "' was configured as an event handler, but does not exist.")
                }
                e.listenTo(t, r, i)
            })
        }

        function r(e, t, n, r) {
            e.listenTo(t, n, r)
        }

        function i(e, t, r, i) {
            var s = i.split(/\s+/);
            n.each(s, function(n) {
                var i = e[n];
                e.stopListening(t, r, i)
            })
        }

        function o(e, t, n, r) {
            e.stopListening(t, n, r)
        }

        function u(e, t, r, i, s) {
            if (!t || !r) {
                return
            }
            if (n.isFunction(r)) {
                r = r.call(e)
            }
            n.each(r, function(r, o) {
                if (n.isFunction(r)) {
                    i(e, t, o, r)
                } else {
                    s(e, t, o, r)
                }
            })
        }
        e.bindEntityEvents = function(e, n, i) {
            u(e, n, i, r, t)
        };
        e.unbindEntityEvents = function(e, t, n) {
            u(e, t, n, o, i)
        }
    })(r);
    r.Callbacks = function() {
        this._deferred = r.$.Deferred();
        this._callbacks = []
    };
    n.extend(r.Callbacks.prototype, {
        add: function(e, t) {
            this._callbacks.push({
                cb: e,
                ctx: t
            });
            this._deferred.done(function(n, r) {
                if (t) {
                    n = t
                }
                e.call(n, r)
            })
        },
        run: function(e, t) {
            this._deferred.resolve(t, e)
        },
        reset: function() {
            var e = this._callbacks;
            this._deferred = r.$.Deferred();
            this._callbacks = [];
            n.each(e, function(e) {
                this.add(e.cb, e.ctx)
            }, this)
        }
    });
    r.Controller = function(e) {
        this.triggerMethod = r.triggerMethod;
        this.options = e || {};
        if (n.isFunction(this.initialize)) {
            this.initialize(this.options)
        }
    };
    r.Controller.extend = r.extend;
    n.extend(r.Controller.prototype, t.Events, {
        close: function() {
            this.stopListening();
            var e = Array.prototype.slice.call(arguments);
            this.triggerMethod.apply(this, ["close"].concat(e));
            this.off()
        }
    });
    r.Region = function(e) {
        this.options = e || {};
        this.el = r.getOption(this, "el");
        if (!this.el) {
            s("An 'el' must be specified for a region.", "NoElError")
        }
        if (this.initialize) {
            var t = Array.prototype.slice.apply(arguments);
            this.initialize.apply(this, t)
        }
    };
    n.extend(r.Region, {
        buildRegion: function(e, t) {
            var r = n.isString(e);
            var i = n.isString(e.selector);
            var o = n.isUndefined(e.regionType);
            var u = n.isFunction(e);
            if (!u && !r && !i) {
                s("Region must be specified as a Region type, a selector string or an object with selector property")
            }
            var a, f;
            if (r) {
                a = e
            }
            if (e.selector) {
                a = e.selector;
                delete e.selector
            }
            if (u) {
                f = e
            }
            if (!u && o) {
                f = t
            }
            if (e.regionType) {
                f = e.regionType;
                delete e.regionType
            }
            if (r || u) {
                e = {}
            }
            e.el = a;
            var l = new f(e);
            if (e.parentEl) {
                l.getEl = function(t) {
                    var r = e.parentEl;
                    if (n.isFunction(r)) {
                        r = r()
                    }
                    return r.find(t)
                }
            }
            return l
        }
    });
    n.extend(r.Region.prototype, t.Events, {
        show: function(e, t) {
            this.ensureEl();
            var i = t || {};
            var s = e.isClosed || n.isUndefined(e.$el);
            var o = e !== this.currentView;
            var u = !!i.preventClose;
            var a = !u && o;
            if (a) {
                this.close()
            }
            e.render();
            r.triggerMethod.call(this, "before:show", e);
            if (n.isFunction(e.triggerMethod)) {
                e.triggerMethod("before:show")
            } else {
                r.triggerMethod.call(e, "before:show")
            }
            if (o || s) {
                this.open(e)
            }
            this.currentView = e;
            r.triggerMethod.call(this, "show", e);
            if (n.isFunction(e.triggerMethod)) {
                e.triggerMethod("show")
            } else {
                r.triggerMethod.call(e, "show")
            }
            return this
        },
        ensureEl: function() {
            if (!this.$el || this.$el.length === 0) {
                this.$el = this.getEl(this.el)
            }
        },
        getEl: function(e) {
            return r.$(e)
        },
        open: function(e) {
            this.$el.empty().append(e.el)
        },
        close: function() {
            var e = this.currentView;
            if (!e || e.isClosed) {
                return
            }
            if (e.close) {
                e.close()
            } else if (e.remove) {
                e.remove()
            }
            r.triggerMethod.call(this, "close", e);
            delete this.currentView
        },
        attachView: function(e) {
            this.currentView = e
        },
        reset: function() {
            this.close();
            delete this.$el
        }
    });
    r.Region.extend = r.extend;
    r.RegionManager = function(e) {
        var t = e.Controller.extend({
            constructor: function(t) {
                this._regions = {};
                e.Controller.prototype.constructor.call(this, t)
            },
            addRegions: function(e, t) {
                var r = {};
                n.each(e, function(e, i) {
                    if (n.isString(e)) {
                        e = {
                            selector: e
                        }
                    }
                    if (e.selector) {
                        e = n.defaults({}, e, t)
                    }
                    var s = this.addRegion(i, e);
                    r[i] = s
                }, this);
                return r
            },
            addRegion: function(t, r) {
                var i;
                var s = n.isObject(r);
                var o = n.isString(r);
                var u = !!r.selector;
                if (o || s && u) {
                    i = e.Region.buildRegion(r, e.Region)
                } else if (n.isFunction(r)) {
                    i = e.Region.buildRegion(r, e.Region)
                } else {
                    i = r
                }
                this._store(t, i);
                this.triggerMethod("region:add", t, i);
                return i
            },
            get: function(e) {
                return this._regions[e]
            },
            removeRegion: function(e) {
                var t = this._regions[e];
                this._remove(e, t)
            },
            removeRegions: function() {
                n.each(this._regions, function(e, t) {
                    this._remove(t, e)
                }, this)
            },
            closeRegions: function() {
                n.each(this._regions, function(e, t) {
                    e.close()
                }, this)
            },
            close: function() {
                this.removeRegions();
                e.Controller.prototype.close.apply(this, arguments)
            },
            _store: function(e, t) {
                this._regions[e] = t;
                this._setLength()
            },
            _remove: function(e, t) {
                t.close();
                t.stopListening();
                delete this._regions[e];
                this._setLength();
                this.triggerMethod("region:remove", e, t)
            },
            _setLength: function() {
                this.length = n.size(this._regions)
            }
        });
        e.actAsCollection(t.prototype, "_regions");
        return t
    }(r);
    r.TemplateCache = function(e) {
        this.templateId = e
    };
    n.extend(r.TemplateCache, {
        templateCaches: {},
        get: function(e) {
            var t = this.templateCaches[e];
            if (!t) {
                t = new r.TemplateCache(e);
                this.templateCaches[e] = t
            }
            return t.load()
        },
        clear: function() {
            var e;
            var t = i.call(arguments);
            var n = t.length;
            if (n > 0) {
                for (e = 0; e < n; e++) {
                    delete this.templateCaches[t[e]]
                }
            } else {
                this.templateCaches = {}
            }
        }
    });
    n.extend(r.TemplateCache.prototype, {
        load: function() {
            if (this.compiledTemplate) {
                return this.compiledTemplate
            }
            var e = this.loadTemplate(this.templateId);
            this.compiledTemplate = this.compileTemplate(e);
            return this.compiledTemplate
        },
        loadTemplate: function(e) {
            var t = r.$(e).html();
            if (!t || t.length === 0) {
                s("Could not find template: '" + e + "'", "NoTemplateError")
            }
            return t
        },
        compileTemplate: function(e) {
            return n.template(e)
        }
    });
    r.Renderer = {
        render: function(e, t) {
            if (!e) {
                s("Cannot render the template since it's false, null or undefined.", "TemplateNotFoundError")
            }
            var n;
            if (typeof e === "function") {
                n = e
            } else {
                n = r.TemplateCache.get(e)
            }
            return n(t)
        }
    };
    r.View = t.View.extend({
        constructor: function(e) {
            n.bindAll(this, "render");
            this.options = n.extend({}, n.result(this, "options"), n.isFunction(e) ? e.call(this) : e);
            this.events = this.normalizeUIKeys(n.result(this, "events"));
            if (n.isObject(this.behaviors)) {
                new r.Behaviors(this)
            }
            t.View.prototype.constructor.apply(this, arguments);
            r.MonitorDOMRefresh(this);
            this.listenTo(this, "show", this.onShowCalled)
        },
        triggerMethod: r.triggerMethod,
        normalizeMethods: r.normalizeMethods,
        getTemplate: function() {
            return r.getOption(this, "template")
        },
        mixinTemplateHelpers: function(e) {
            e = e || {};
            var t = r.getOption(this, "templateHelpers");
            if (n.isFunction(t)) {
                t = t.call(this)
            }
            return n.extend(e, t)
        },
        normalizeUIKeys: function(e) {
            var t = n.result(this, "ui");
            return r.normalizeUIKeys(e, t)
        },
        configureTriggers: function() {
            if (!this.triggers) {
                return
            }
            var e = {};
            var t = this.normalizeUIKeys(n.result(this, "triggers"));
            n.each(t, function(t, r) {
                var i = n.isObject(t);
                var s = i ? t.event : t;
                e[r] = function(e) {
                    if (e) {
                        var n = e.preventDefault;
                        var r = e.stopPropagation;
                        var o = i ? t.preventDefault : n;
                        var u = i ? t.stopPropagation : r;
                        if (o && n) {
                            n.apply(e)
                        }
                        if (u && r) {
                            r.apply(e)
                        }
                    }
                    var a = {
                        view: this,
                        model: this.model,
                        collection: this.collection
                    };
                    this.triggerMethod(s, a)
                }
            }, this);
            return e
        },
        delegateEvents: function(e) {
            this._delegateDOMEvents(e);
            r.bindEntityEvents(this, this.model, r.getOption(this, "modelEvents"));
            r.bindEntityEvents(this, this.collection, r.getOption(this, "collectionEvents"))
        },
        _delegateDOMEvents: function(e) {
            e = e || this.events;
            if (n.isFunction(e)) {
                e = e.call(this)
            }
            var r = {};
            var i = n.result(this, "behaviorEvents") || {};
            var s = this.configureTriggers();
            n.extend(r, i, e, s);
            t.View.prototype.delegateEvents.call(this, r)
        },
        undelegateEvents: function() {
            var e = Array.prototype.slice.call(arguments);
            t.View.prototype.undelegateEvents.apply(this, e);
            r.unbindEntityEvents(this, this.model, r.getOption(this, "modelEvents"));
            r.unbindEntityEvents(this, this.collection, r.getOption(this, "collectionEvents"))
        },
        onShowCalled: function() {},
        close: function() {
            if (this.isClosed) {
                return
            }
            var e = Array.prototype.slice.call(arguments);
            var t = this.triggerMethod.apply(this, ["before:close"].concat(e));
            if (t === false) {
                return
            }
            this.isClosed = true;
            this.triggerMethod.apply(this, ["close"].concat(e));
            this.unbindUIElements();
            this.remove()
        },
        bindUIElements: function() {
            if (!this.ui) {
                return
            }
            if (!this._uiBindings) {
                this._uiBindings = this.ui
            }
            var e = n.result(this, "_uiBindings");
            this.ui = {};
            n.each(n.keys(e), function(t) {
                var n = e[t];
                this.ui[t] = this.$(n)
            }, this)
        },
        unbindUIElements: function() {
            if (!this.ui || !this._uiBindings) {
                return
            }
            n.each(this.ui, function(e, t) {
                delete this.ui[t]
            }, this);
            this.ui = this._uiBindings;
            delete this._uiBindings
        }
    });
    r.ItemView = r.View.extend({
        constructor: function() {
            r.View.prototype.constructor.apply(this, arguments)
        },
        serializeData: function() {
            var e = {};
            if (this.model) {
                e = this.model.toJSON()
            } else if (this.collection) {
                e = {
                    items: this.collection.toJSON()
                }
            }
            return e
        },
        render: function() {
            this.isClosed = false;
            this.triggerMethod("before:render", this);
            this.triggerMethod("item:before:render", this);
            var e = this.serializeData();
            e = this.mixinTemplateHelpers(e);
            var t = this.getTemplate();
            var n = r.Renderer.render(t, e);
            this.$el.html(n);
            this.bindUIElements();
            this.triggerMethod("render", this);
            this.triggerMethod("item:rendered", this);
            return this
        },
        close: function() {
            if (this.isClosed) {
                return
            }
            this.triggerMethod("item:before:close");
            r.View.prototype.close.apply(this, arguments);
            this.triggerMethod("item:closed")
        }
    });
    r.CollectionView = r.View.extend({
        itemViewEventPrefix: "itemview",
        constructor: function(e) {
            this._initChildViewStorage();
            r.View.prototype.constructor.apply(this, arguments);
            this._initialEvents();
            this.initRenderBuffer()
        },
        initRenderBuffer: function() {
            this.elBuffer = document.createDocumentFragment();
            this._bufferedChildren = []
        },
        startBuffering: function() {
            this.initRenderBuffer();
            this.isBuffering = true
        },
        endBuffering: function() {
            this.isBuffering = false;
            this.appendBuffer(this, this.elBuffer);
            this._triggerShowBufferedChildren();
            this.initRenderBuffer()
        },
        _triggerShowBufferedChildren: function() {
            if (this._isShown) {
                n.each(this._bufferedChildren, function(e) {
                    r.triggerMethod.call(e, "show")
                });
                this._bufferedChildren = []
            }
        },
        _initialEvents: function() {
            if (this.collection) {
                this.listenTo(this.collection, "add", this.addChildView);
                this.listenTo(this.collection, "remove", this.removeItemView);
                this.listenTo(this.collection, "reset", this.render)
            }
        },
        addChildView: function(e, t, n) {
            this.closeEmptyView();
            var r = this.getItemView(e);
            var i = this.collection.indexOf(e);
            this.addItemView(e, r, i)
        },
        onShowCalled: function() {
            this.children.each(function(e) {
                r.triggerMethod.call(e, "show")
            })
        },
        triggerBeforeRender: function() {
            this.triggerMethod("before:render", this);
            this.triggerMethod("collection:before:render", this)
        },
        triggerRendered: function() {
            this.triggerMethod("render", this);
            this.triggerMethod("collection:rendered", this)
        },
        render: function() {
            this.isClosed = false;
            this.triggerBeforeRender();
            this._renderChildren();
            this.triggerRendered();
            return this
        },
        _renderChildren: function() {
            this.startBuffering();
            this.closeEmptyView();
            this.closeChildren();
            if (!this.isEmpty(this.collection)) {
                this.showCollection()
            } else {
                this.showEmptyView()
            }
            this.endBuffering()
        },
        showCollection: function() {
            var e;
            this.collection.each(function(t, n) {
                e = this.getItemView(t);
                this.addItemView(t, e, n)
            }, this)
        },
        showEmptyView: function() {
            var e = this.getEmptyView();
            if (e && !this._showingEmptyView) {
                this._showingEmptyView = true;
                var n = new t.Model;
                this.addItemView(n, e, 0)
            }
        },
        closeEmptyView: function() {
            if (this._showingEmptyView) {
                this.closeChildren();
                delete this._showingEmptyView
            }
        },
        getEmptyView: function() {
            return r.getOption(this, "emptyView")
        },
        getItemView: function(e) {
            var t = r.getOption(this, "itemView");
            if (!t) {
                s("An `itemView` must be specified", "NoItemViewError")
            }
            return t
        },
        addItemView: function(e, t, i) {
            var s = r.getOption(this, "itemViewOptions");
            if (n.isFunction(s)) {
                s = s.call(this, e, i)
            }
            var o = this.buildItemView(e, t, s);
            this.addChildViewEventForwarding(o);
            this.triggerMethod("before:item:added", o);
            this.children.add(o);
            this.renderItemView(o, i);
            if (this._isShown && !this.isBuffering) {
                r.triggerMethod.call(o, "show")
            }
            this.triggerMethod("after:item:added", o);
            return o
        },
        addChildViewEventForwarding: function(e) {
            var t = r.getOption(this, "itemViewEventPrefix");
            this.listenTo(e, "all", function() {
                var s = i.call(arguments);
                var o = s[0];
                var u = this.normalizeMethods(this.getItemEvents());
                s[0] = t + ":" + o;
                s.splice(1, 0, e);
                if (typeof u !== "undefined" && n.isFunction(u[o])) {
                    u[o].apply(this, s)
                }
                r.triggerMethod.apply(this, s)
            }, this)
        },
        getItemEvents: function() {
            if (n.isFunction(this.itemEvents)) {
                return this.itemEvents.call(this)
            }
            return this.itemEvents
        },
        renderItemView: function(e, t) {
            e.render();
            this.appendHtml(this, e, t)
        },
        buildItemView: function(e, t, r) {
            var i = n.extend({
                model: e
            }, r);
            return new t(i)
        },
        removeItemView: function(e) {
            var t = this.children.findByModel(e);
            this.removeChildView(t);
            this.checkEmpty()
        },
        removeChildView: function(e) {
            if (e) {
                if (e.close) {
                    e.close()
                } else if (e.remove) {
                    e.remove()
                }
                this.stopListening(e);
                this.children.remove(e)
            }
            this.triggerMethod("item:removed", e)
        },
        isEmpty: function(e) {
            return !this.collection || this.collection.length === 0
        },
        checkEmpty: function() {
            if (this.isEmpty(this.collection)) {
                this.showEmptyView()
            }
        },
        appendBuffer: function(e, t) {
            e.$el.append(t)
        },
        appendHtml: function(e, t, n) {
            if (e.isBuffering) {
                t.$el.addClass("out");
                e.elBuffer.appendChild(t.el);
                e._bufferedChildren.push(t);
                t.$el.addClass("in")
            } else {
                t.$el.addClass("out");
                e.$el.append(t.el);
                t.$el.addClass("in")
            }
        },
        _initChildViewStorage: function() {
            this.children = new t.ChildViewContainer
        },
        close: function() {
            if (this.isClosed) {
                return
            }
            this.triggerMethod("collection:before:close");
            this.closeChildren();
            this.triggerMethod("collection:closed");
            r.View.prototype.close.apply(this, arguments)
        },
        closeChildren: function() {
            this.children.each(function(e) {
                this.removeChildView(e)
            }, this);
            this.checkEmpty()
        }
    });
    r.CompositeView = r.CollectionView.extend({
        constructor: function() {
            r.CollectionView.prototype.constructor.apply(this, arguments)
        },
        _initialEvents: function() {
            this.once("render", function() {
                if (this.collection) {
                    this.listenTo(this.collection, "add", this.addChildView);
                    this.listenTo(this.collection, "remove", this.removeItemView);
                    this.listenTo(this.collection, "reset", this._renderChildren)
                }
            })
        },
        getItemView: function(e) {
            var t = r.getOption(this, "itemView") || this.constructor;
            if (!t) {
                s("An `itemView` must be specified", "NoItemViewError")
            }
            return t
        },
        serializeData: function() {
            var e = {};
            if (this.model) {
                e = this.model.toJSON()
            }
            return e
        },
        render: function() {
            this.isRendered = true;
            this.isClosed = false;
            this.resetItemViewContainer();
            this.triggerBeforeRender();
            var e = this.renderModel();
            this.$el.html(e);
            this.bindUIElements();
            this.triggerMethod("composite:model:rendered");
            this._renderChildren();
            this.triggerMethod("composite:rendered");
            this.triggerRendered();
            return this
        },
        _renderChildren: function() {
            if (this.isRendered) {
                this.triggerMethod("composite:collection:before:render");
                r.CollectionView.prototype._renderChildren.call(this);
                this.triggerMethod("composite:collection:rendered")
            }
        },
        renderModel: function() {
            var e = {};
            e = this.serializeData();
            e = this.mixinTemplateHelpers(e);
            var t = this.getTemplate();
            return r.Renderer.render(t, e)
        },
        appendBuffer: function(e, t) {
            var n = this.getItemViewContainer(e);
            n.append(t)
        },
        appendHtml: function(e, t, n) {
            if (e.isBuffering) {
                e.elBuffer.appendChild(t.el);
                e._bufferedChildren.push(t)
            } else {
                var r = this.getItemViewContainer(e);
                r.append(t.el)
            }
        },
        getItemViewContainer: function(e) {
            if ("$itemViewContainer" in e) {
                return e.$itemViewContainer
            }
            var t;
            var i = r.getOption(e, "itemViewContainer");
            if (i) {
                var o = n.isFunction(i) ? i.call(e) : i;
                if (o.charAt(0) === "@" && e.ui) {
                    t = e.ui[o.substr(4)]
                } else {
                    t = e.$(o)
                }
                if (t.length <= 0) {
                    s("The specified `itemViewContainer` was not found: " + e.itemViewContainer, "ItemViewContainerMissingError")
                }
            } else {
                t = e.$el
            }
            e.$itemViewContainer = t;
            return t
        },
        resetItemViewContainer: function() {
            if (this.$itemViewContainer) {
                delete this.$itemViewContainer
            }
        }
    });
    r.Layout = r.ItemView.extend({
        regionType: r.Region,
        constructor: function(e) {
            e = e || {};
            this._firstRender = true;
            this._initializeRegions(e);
            r.ItemView.prototype.constructor.call(this, e)
        },
        render: function() {
            if (this.isClosed) {
                this._initializeRegions()
            }
            if (this._firstRender) {
                this._firstRender = false
            } else if (!this.isClosed) {
                this._reInitializeRegions()
            }
            return r.ItemView.prototype.render.apply(this, arguments)
        },
        close: function() {
            if (this.isClosed) {
                return
            }
            this.regionManager.close();
            r.ItemView.prototype.close.apply(this, arguments)
        },
        addRegion: function(e, t) {
            var n = {};
            n[e] = t;
            return this._buildRegions(n)[e]
        },
        addRegions: function(e) {
            this.regions = n.extend({}, this.regions, e);
            return this._buildRegions(e)
        },
        removeRegion: function(e) {
            delete this.regions[e];
            return this.regionManager.removeRegion(e)
        },
        getRegion: function(e) {
            return this.regionManager.get(e)
        },
        _buildRegions: function(e) {
            var t = this;
            var n = {
                regionType: r.getOption(this, "regionType"),
                parentEl: function() {
                    return t.$el
                }
            };
            return this.regionManager.addRegions(e, n)
        },
        _initializeRegions: function(e) {
            var t;
            this._initRegionManager();
            if (n.isFunction(this.regions)) {
                t = this.regions(e)
            } else {
                t = this.regions || {}
            }
            this.addRegions(t)
        },
        _reInitializeRegions: function() {
            this.regionManager.closeRegions();
            this.regionManager.each(function(e) {
                e.reset()
            })
        },
        _initRegionManager: function() {
            this.regionManager = new r.RegionManager;
            this.listenTo(this.regionManager, "region:add", function(e, t) {
                this[e] = t;
                this.trigger("region:add", e, t)
            });
            this.listenTo(this.regionManager, "region:remove", function(e, t) {
                delete this[e];
                this.trigger("region:remove", e, t)
            })
        }
    });
    r.Behavior = function(e, t) {
        function n(t, n) {
            this.view = n;
            this.defaults = e.result(this, "defaults") || {};
            this.options = e.extend({}, this.defaults, t);
            this.$ = function() {
                return this.view.$.apply(this.view, arguments)
            };
            this.initialize.apply(this, arguments)
        }
        e.extend(n.prototype, t.Events, {
            initialize: function() {},
            close: function() {
                this.stopListening()
            },
            triggerMethod: r.triggerMethod
        });
        n.extend = r.extend;
        return n
    }(n, t);
    r.Behaviors = function(e, t) {
        function n(e) {
            this.behaviors = n.parseBehaviors(e, t.result(e, "behaviors"));
            n.wrap(e, this.behaviors, ["bindUIElements", "unbindUIElements", "delegateEvents", "undelegateEvents", "behaviorEvents", "triggerMethod", "setElement", "close"])
        }
        var r = {
            setElement: function(e, n) {
                e.apply(this, t.tail(arguments, 2));
                t.each(n, function(e) {
                    e.$el = this.$el
                }, this)
            },
            close: function(e, n) {
                var r = t.tail(arguments, 2);
                e.apply(this, r);
                t.invoke(n, "close", r)
            },
            bindUIElements: function(e, n) {
                e.apply(this);
                t.invoke(n, e)
            },
            unbindUIElements: function(e, n) {
                e.apply(this);
                t.invoke(n, e)
            },
            triggerMethod: function(e, n) {
                var r = t.tail(arguments, 2);
                e.apply(this, r);
                t.each(n, function(t) {
                    e.apply(t, r)
                })
            },
            delegateEvents: function(n, r) {
                var i = t.tail(arguments, 2);
                n.apply(this, i);
                t.each(r, function(t) {
                    e.bindEntityEvents(t, this.model, e.getOption(t, "modelEvents"));
                    e.bindEntityEvents(t, this.collection, e.getOption(t, "collectionEvents"))
                }, this)
            },
            undelegateEvents: function(n, r) {
                var i = t.tail(arguments, 2);
                n.apply(this, i);
                t.each(r, function(t) {
                    e.unbindEntityEvents(t, this.model, e.getOption(t, "modelEvents"));
                    e.unbindEntityEvents(t, this.collection, e.getOption(t, "collectionEvents"))
                }, this)
            },
            behaviorEvents: function(n, r) {
                var i = {};
                var s = t.result(this, "ui");
                t.each(r, function(n, r) {
                    var o = {};
                    var u = t.clone(t.result(n, "events")) || {};
                    var a = t.result(n, "ui");
                    var f = t.extend({}, s, a);
                    u = e.normalizeUIKeys(u, f);
                    t.each(t.keys(u), function(e) {
                        var i = (new Array(r + 2)).join(" ");
                        var s = e + i;
                        var a = t.isFunction(u[e]) ? u[e] : n[u[e]];
                        o[s] = t.bind(a, n)
                    });
                    i = t.extend(i, o)
                });
                return i
            }
        };
        t.extend(n, {
            behaviorsLookup: function() {
                throw new Error("You must define where your behaviors are stored. See https://github.com/marionettejs/backbone.marionette/blob/master/docs/marionette.behaviors.md#behaviorslookup")
            },
            getBehaviorClass: function(e, r) {
                if (e.behaviorClass) {
                    return e.behaviorClass
                }
                return t.isFunction(n.behaviorsLookup) ? n.behaviorsLookup.apply(this, arguments)[r] : n.behaviorsLookup[r]
            },
            parseBehaviors: function(e, r) {
                return t.map(r, function(t, r) {
                    var i = n.getBehaviorClass(t, r);
                    return new i(t, e)
                })
            },
            wrap: function(e, n, i) {
                t.each(i, function(i) {
                    e[i] = t.partial(r[i], e[i], n)
                })
            }
        });
        return n
    }(r, n);
    r.AppRouter = t.Router.extend({
        constructor: function(e) {
            t.Router.prototype.constructor.apply(this, arguments);
            this.options = e || {};
            var n = r.getOption(this, "appRoutes");
            var i = this._getController();
            this.processAppRoutes(i, n);
            this.on("route", this._processOnRoute, this)
        },
        appRoute: function(e, t) {
            var n = this._getController();
            this._addAppRoute(n, e, t)
        },
        _processOnRoute: function(e, t) {
            var r = n.invert(this.appRoutes)[e];
            if (n.isFunction(this.onRoute)) {
                this.onRoute(e, r, t)
            }
        },
        processAppRoutes: function(e, t) {
            if (!t) {
                return
            }
            var r = n.keys(t).reverse();
            n.each(r, function(n) {
                this._addAppRoute(e, n, t[n])
            }, this)
        },
        _getController: function() {
            return r.getOption(this, "controller")
        },
        _addAppRoute: function(e, t, r) {
            var i = e[r];
            if (!i) {
                s("Method '" + r + "' was not found on the controller")
            }
            this.route(t, r, n.bind(i, e))
        }
    });
    r.Application = function(e) {
        this._initRegionManager();
        this._initCallbacks = new r.Callbacks;
        this.vent = new t.Wreqr.EventAggregator;
        this.commands = new t.Wreqr.Commands;
        this.reqres = new t.Wreqr.RequestResponse;
        this.submodules = {};
        n.extend(this, e);
        this.triggerMethod = r.triggerMethod
    };
    n.extend(r.Application.prototype, t.Events, {
        execute: function() {
            this.commands.execute.apply(this.commands, arguments)
        },
        request: function() {
            return this.reqres.request.apply(this.reqres, arguments)
        },
        addInitializer: function(e) {
            this._initCallbacks.add(e)
        },
        start: function(e) {
            this.triggerMethod("initialize:before", e);
            this._initCallbacks.run(e, this);
            this.triggerMethod("initialize:after", e);
            this.triggerMethod("start", e)
        },
        addRegions: function(e) {
            return this._regionManager.addRegions(e)
        },
        closeRegions: function() {
            this._regionManager.closeRegions()
        },
        removeRegion: function(e) {
            this._regionManager.removeRegion(e)
        },
        getRegion: function(e) {
            return this._regionManager.get(e)
        },
        module: function(e, t) {
            var n = r.Module.getClass(t);
            var s = i.call(arguments);
            s.unshift(this);
            return n.create.apply(n, s)
        },
        _initRegionManager: function() {
            this._regionManager = new r.RegionManager;
            this.listenTo(this._regionManager, "region:add", function(e, t) {
                this[e] = t
            });
            this.listenTo(this._regionManager, "region:remove", function(e, t) {
                delete this[e]
            })
        }
    });
    r.Application.extend = r.extend;
    r.Module = function(e, t, i) {
        this.moduleName = e;
        this.options = n.extend({}, this.options, i);
        this.initialize = i.initialize || this.initialize;
        this.submodules = {};
        this._setupInitializersAndFinalizers();
        this.app = t;
        this.startWithParent = true;
        this.triggerMethod = r.triggerMethod;
        if (n.isFunction(this.initialize)) {
            this.initialize(this.options, e, t)
        }
    };
    r.Module.extend = r.extend;
    n.extend(r.Module.prototype, t.Events, {
        initialize: function() {},
        addInitializer: function(e) {
            this._initializerCallbacks.add(e)
        },
        addFinalizer: function(e) {
            this._finalizerCallbacks.add(e)
        },
        start: function(e) {
            if (this._isInitialized) {
                return
            }
            n.each(this.submodules, function(t) {
                if (t.startWithParent) {
                    t.start(e)
                }
            });
            this.triggerMethod("before:start", e);
            this._initializerCallbacks.run(e, this);
            this._isInitialized = true;
            this.triggerMethod("start", e)
        },
        stop: function() {
            if (!this._isInitialized) {
                return
            }
            this._isInitialized = false;
            r.triggerMethod.call(this, "before:stop");
            n.each(this.submodules, function(e) {
                e.stop()
            });
            this._finalizerCallbacks.run(undefined, this);
            this._initializerCallbacks.reset();
            this._finalizerCallbacks.reset();
            r.triggerMethod.call(this, "stop")
        },
        addDefinition: function(e, t) {
            this._runModuleDefinition(e, t)
        },
        _runModuleDefinition: function(e, i) {
            if (!e) {
                return
            }
            var s = n.flatten([this, this.app, t, r, r.$, n, i]);
            e.apply(this, s)
        },
        _setupInitializersAndFinalizers: function() {
            this._initializerCallbacks = new r.Callbacks;
            this._finalizerCallbacks = new r.Callbacks
        }
    });
    n.extend(r.Module, {
        create: function(e, t, r) {
            var s = e;
            var o = i.call(arguments);
            o.splice(0, 3);
            t = t.split(".");
            var u = t.length;
            var a = [];
            a[u - 1] = r;
            n.each(t, function(t, n) {
                var i = s;
                s = this._getModule(i, t, e, r);
                this._addModuleDefinition(i, s, a[n], o)
            }, this);
            return s
        },
        _getModule: function(e, t, r, i, s) {
            var o = n.extend({}, i);
            var u = this.getClass(i);
            var a = e[t];
            if (!a) {
                a = new u(t, r, o);
                e[t] = a;
                e.submodules[t] = a
            }
            return a
        },
        getClass: function(e) {
            var t = r.Module;
            if (!e) {
                return t
            }
            if (e.prototype instanceof t) {
                return e
            }
            return e.moduleClass || t
        },
        _addModuleDefinition: function(e, t, n, r) {
            var i = this._getDefine(n);
            var s = this._getStartWithParent(n, t);
            if (i) {
                t.addDefinition(i, r)
            }
            this._addStartWithParent(e, t, s)
        },
        _getStartWithParent: function(e, t) {
            var i;
            if (n.isFunction(e) && e.prototype instanceof r.Module) {
                i = t.constructor.prototype.startWithParent;
                return n.isUndefined(i) ? true : i
            }
            if (n.isObject(e)) {
                i = e.startWithParent;
                return n.isUndefined(i) ? true : i
            }
            return true
        },
        _getDefine: function(e) {
            if (n.isFunction(e) && !(e.prototype instanceof r.Module)) {
                return e
            }
            if (n.isObject(e)) {
                return e.define
            }
            return null
        },
        _addStartWithParent: function(e, t, n) {
            t.startWithParent = t.startWithParent && n;
            if (!t.startWithParent || !!t.startWithParentIsConfigured) {
                return
            }
            t.startWithParentIsConfigured = true;
            e.addInitializer(function(e) {
                if (t.startWithParent) {
                    t.start(e)
                }
            })
        }
    });
    return r
}(this, Backbone, _)