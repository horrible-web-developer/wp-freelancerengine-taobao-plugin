<script type="text/template" id="withdraw-require-js">
    <div class="fre-table-col withdraw-username-col">{{= user_name }}</div>
    <div class="fre-table-col withdraw-alipay-col">{{= alipay_number }}</div>
    <div class="fre-table-col withdraw-momey-col">{{= amount }}</div>
    <div class="fre-table-col project-action-col">
        <# if ( post_status == 'pending' ) { #>
            <a class="freelancer-withdraw-action" data-action="withdraw" data-confirm-id="{{= user_id }}"><?php echo __( 'Withdraw', ET_DOMAIN ) ?>
            </a>
        </div>
        <# } else { #>
            <a class="withdraw-delete-action" data-action="withdraw-delete" data-confirm-id="{{= user_id }}"><?php echo __( 'Delete', ET_DOMAIN ) ?>
            </a>
        <# } #>
    </div>
</script>