<script type="text/template" id="cdkey-require-js">
    <div class="fre-table-col withdraw-username-col">{{= cdkey_number }}</div>
    <div class="fre-table-col withdraw-alipay-col">{{= cdkey_status }}</div>
    <div class="fre-table-col withdraw-momey-col">{{= et_price }}</div>
    <div class="fre-table-col project-action-col">
    	<a class="project-action" data-action="delete" data-cdkey-id="{{= cdkey_ID }}">
           <?php echo __( 'Delete', ET_DOMAIN ) ?>
        </a>    	
    </div>        
</script>