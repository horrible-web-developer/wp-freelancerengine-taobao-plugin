<script type="text/template" id="contact-require-js">
    <div class="fre-table-col withdraw-username-col">{{= user_name }}</div>
    <div class="fre-table-col withdraw-alipay-col">{{= phone_number }}</div>
    <div class="fre-table-col withdraw-momey-col">{{= wechat_number }}</div>
    <div class="fre-table-col withdraw-issue-col">{{= issue }}</div>        
</script>