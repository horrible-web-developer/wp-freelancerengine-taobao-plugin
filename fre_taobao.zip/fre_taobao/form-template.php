<?php
    $taobao_key = ae_get_option('taobao');
    if (!$taobao_key['taobao_merchant_spm'] || !$taobao_key['taobao_merchant_id']) return false;
    $taobao_url = "https://item.taobao.com/item.htm"."?spm=".$taobao_key['taobao_merchant_spm']."&id=".$taobao_key['taobao_merchant_id'];
?>
<div id="fre-payment-taobao" class="panel-collapse collapse fre-payment-proccess">
    <a href="<?php echo $taobao_url;?>" class="fre-btn btn-visit-site" data-type="taobao"><?php _e("Visit Taobao Site", ET_DOMAIN); ?></a>
    <form class="modal-form" id="taobao_form" action="#" method="POST" autocomplete="on">
        <div class="fre-input-field">
            <label class="fre-field-title" for=""><?php _e('Taobao CD-KEY',ET_DOMAIN);?></label>
            <input  tabindex="20" id="taobao_cd_key" name="taobao_cd_key" type="text" size="20" class="bg-default-input not_empty required" placeholder="<?php _e('Your Taobao CD-KEY', ET_DOMAIN);?>" />
        </div>
        <div class="fre-proccess-payment-btn">
            <button class="fre-btn" id="submit_fre_taobao" ><?php _e('Make Payment', ET_DOMAIN);?></button>
        </div>
    </form>
</div>