<?php
/**
 * Created by PhpStorm.
 * User: Jack Bui
 * Date: 11/16/2015
 * Time: 9:52 AM
 */
class FRE_Taobao_Cdkey extends AE_Base{

    public static $instance;

    /**
     * getInstance method
     *
     */
    public static function getInstance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * the constructor of this class
     * @param string $code
     * @param string $signal,
     * @param boolean $isDefault true if this currency is default and false if it isn't
     * @param float $rateExchange
     *
     * @return void
     *
     */
    public  function __construct(){

    }

    /**
      * unit function of this class
      *
      * @param void
      * @return void
      * @since 1.0
      * @package FREELANCEENGINE
      * @category FRE CREDIT
      * @author Jack Bui
      */
    public function init(){
        //filter gateway to payment method
        $this->add_action('wp_ajax_fre_credit_charge_taobao', 'chargeTaobaoCredit');
        $this->add_action('wp_ajax_fre_generate_cd_key', 'insertCdkey');
        $this->add_action('wp_ajax_fre_cdkey_content', 'displayCdkey');
        $this->add_action('wp_ajax_fre_delete_cdkey', 'deleteCdkey');
    }

    public function chargeTaobaoCredit(){
        global $wpdb;
        $request = $_REQUEST;
        $cdkey = $request['cdkey'];       
         
        $validate = $this->validateCdkey($cdkey);
        if ( $validate ) {
  	 	   global $user_ID;
  	 	   $et_price = get_post_meta($validate, 'et_price', true);
  			 $default = array(
  	            //"package_name" => $pack->post_title,
  	            "amount" => $et_price, // amount in cents
  	            "currency" => fre_credit_get_payment_currency(),
  	            "destination" => '',
  	            "source_transaction" => '',
  	            "commission_fee"=> 0,
  	            "statement_descriptor" => '',
  	            "history_type"=> 'deposit',
  	            "post_title"=> 'Deposited',
  	            "payment" => 0
  	        );
          $user_wallet = FRE_Credit_Users::getUserWallet($user_ID);
          $wallet = fre_credit_convert_wallet($number);
          //$number = FRE_Credit_Currency_Exchange::convertToUserCurrency($user_ID, $wallet);
          $number = $et_price;
          $user_wallet->balance = $number + $user_wallet->balance;
          FRE_Credit_Users::setUserWallet($user_ID, $user_wallet);
  			  
          $default['status'] = 'completed';
          FRE_Credit_History::saveHistory($default);//   FRE_Credit_History::saveHistory($default);
  			  
          $args = array(
            'post_type'   => 'taobao_cdkey',
            'post_title'  => $request['cdkey']           
          );
          $sql =  "SELECT * FROM $wpdb->posts WHERE post_title = '".$cdkey."' AND post_type = 'taobao_cdkey'";
          $retrieve_data = $wpdb->get_results( $sql );
          $ID = $retrieve_data[0]->ID;
          wp_update_post(array('ID' => $ID, 'post_status' => 'trash'));

  	    	wp_send_json( array(
  	        	'success' => true,
              'msg'     => "Your Credit Card was charged successfully."
  	      	));
	    } else {	    	
	    	wp_send_json( array(
	        	'success' => false,
	        	'msg'     => "Your Taobao CD key is invalid."
	      	));
	    }
    }

    public function insertCdkey(){
         global $wpdb;
         $request = $_REQUEST;
         $cdkey = $request['cdkey'];
         $status = $request['cdkeystatus'];
         $cdkeytype = $request['moneytype'];
         $val = true;      
         if(isset( $cdkey )){
          while( $val ){           
              $keygen = array(
  	            array("A","B","C","D","E","F","G","H","I","J"),
  	            array("K","L","M","N","O","P","Q","R","S","T"),
  	            array("U","V","W","X","y","Z","a","b","c","d"),
  	            array("e","f","g","h","i","j","k","l","m","n"),
  	            array("o","p","q","r","s","t","u","v","w","x"),
  	            array("y","z","$","%","#","~","(",")","[","]"),
  	            array("&","^","@","+","_","!","=","[","]","?"),
  	            array("0","1","2","3","4","5","6","7","8","9")
              );
              $number = array();
              $length = 10;
              for ($i = 0; $i < $length; $i++) {
                  $number[]	=	rand(0,9);
              }
              $key = array();
              foreach ($number as $value) {
                  $rang 	= rand(0,7);
              	$key[] 	= $keygen[$rang][$value];
              }
              $final_key 	= implode("", $key);
              $sql =  "SELECT * FROM $wpdb->posts WHERE post_title = '".$final_key."' AND post_type = 'taobao_cdkey'";
              $val = $wpdb->get_results( $sql );            
              }
              $wpdb->insert(
                  'wp_posts',
                  array(
                      'post_title'       => $final_key,
                      'post_status'      => 'publish',
                      'post_parent'      =>  $cdkey,
                      'post_type'        => 'taobao_cdkey'
                  ),
                  array(
                      '%s',
                      '%s',
                      '%s',
                      '%s'
                  )
                );
              $message = __( "Generate cdkey successful!", ET_DOMAIN );
              wp_send_json( array(
              'success'     => true,
              'msg'         => $message,
              'final_key'     => $final_key,
              'html'      => $html
            )); 
        }                    
    }
      

    public function displayCdkey(){
        global $ae_post_factory, $post;
        $page = $_REQUEST['page'];
        extract( $_REQUEST );
        $cdkey_args = array(
            'paged'       => $page,
            'post_type'   => $query['post_type'],
            'post_status' => array('publish', 'pending', 'trash'),                                
        );       

        //check args showposts
        if ( isset( $query['showposts'] ) && $query['showposts'] ) {
            $query_args['showposts'] = $query['showposts'];
        }
        if ( isset( $query['cdkey_money_amount'] ) && $query['cdkey_money_amount'] ) {
            $cdkey_args['post_parent'] = $query['cdkey_money_amount'];
        }
        if ( isset( $query['cdkey_current_status'] ) && $query['cdkey_current_status'] ) {
            $cdkey_args['post_status'] = $query['cdkey_current_status'];
        }        
        $cdkey_query = new WP_Query($cdkey_args);
        $cdkey_post_data = array();

        if( $cdkey_query->have_posts() ) {
            while( $cdkey_query->have_posts() ) {
                $cdkey_query->the_post();
                $cdkey_number = $post->post_title;
                $cdkey_status = $post->post_status;
                $et_price = get_post_meta($post->post_parent, 'et_price', true);
                $cdkey_ID = $post->ID;                                        
                $cdkey_post_data[] = array( 'cdkey_number' => $cdkey_number, 'cdkey_status' => $cdkey_status, 'et_price' => $et_price, 'cdkey_ID' => $cdkey_ID );     
        
            }
        }     


        $paginate = '';
        if ( $page < $cdkey_query->max_num_pages ) {
            ob_start();
            ae_pagination( $cdkey_query, $page, $_REQUEST['paginate'] );
            $paginate = ob_get_clean();
        }

        if ( $page == $cdkey_query->max_num_pages && $_REQUEST['paginate'] == 'page' ) {
            ob_start();
            ae_pagination( $cdkey_query, $page, $_REQUEST['paginate'] );
            $paginate = ob_get_clean();
        }


        /**
         * send data to client
         */
        if ( ! empty( $cdkey_post_data ) ) {
            wp_send_json( array(
                'data'          => $cdkey_post_data,
                'paginate'      => $paginate,
                'msg'           => __( "Successs", ET_DOMAIN ),
                'success'       => true,
                'max_num_pages' => $cdkey_query->max_num_pages,
                'total'         => $cdkey_query->found_posts
            ) );
        } else {
            wp_send_json( array(
                'success' => false,
                'data'    => array()
            ));
        }
    }
 
    public function deleteCdkey(){
        global $post, $user_ID;
        $request    = $_REQUEST;
        $cdkey_id 	= $request['ID'];
        if ( isset( $cdkey_id ) && $cdkey_id != '' ) {
            $cdkey = get_post( $cdkey_id, ARRAY_A );
            $result  = wp_delete_post( $cdkey_id );
            if ( is_wp_error( $result ) ) {
                wp_send_json( array(
            	    'success' => false,
                    'msg'     => $result->get_error_message()
                ));
            } else {
                $message = __( "Delete cdkey successful!", ET_DOMAIN );
                wp_send_json( array(
                	'success' => true,
                    'msg'     => $message
                ));
            }
        } else {
            $message = __( "Request failed. Please refresh the page and try again", ET_DOMAIN );
            wp_send_json( array(
            	'success' => false,
            	'msg'     => $message,
            ));
        }
    }
    private function validateCdkey($cdkey) {
          global $wpdb;
          $sql =  "SELECT * FROM $wpdb->posts WHERE post_title = '".$cdkey."' AND post_type = 'taobao_cdkey'";
          $retrieve_data = $wpdb->get_results( $sql );
          $ID = $retrieve_data[0]->ID;
  		
  		if (is_array($retrieve_data)) {
  			foreach ($retrieve_data as $val) {
  				if ($val->post_status == 'publish') return $val->post_parent;
  			}
  		}
  		return 0;
    }

    private function getCreditPlans() {
    }
}