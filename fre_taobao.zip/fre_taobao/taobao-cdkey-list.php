<?php
	global $wpdb, $wp_query, $ae_post_factory, $post, $current_user, $user_ID;
	$ae_pack = $ae_post_factory->get('fre_credit_plan');
	$packs = $ae_pack->fetch('fre_credit_plan');
    define( 'NO_RESULT', __( '<span class="project-no-results">There are no cdkeys.</span>', ET_DOMAIN ) );
?>
        
<div class="fre-page-wrapper tabs-credits" id="generate-cd-key">
    <div class="fre-page-title">
        <div class="container">
            <h2><?php _e('Generate cd-key numbers' , ET_DOMAIN) ?></h2>
        </div>
    </div>
    <div class="fre-page-section">
        <div class="container">
            <div class="fre-credit-wrap">
                <div class="fre-tab-content">
                    <div id="fre-cdkey-content" class="fre-cdkey-content fre-panel-tab active">
                        <div class="fre-credit-box">
                            <div class="credit-balance-wrap">
                              	<form class="modal-form" id="cdkey_form" action="#" method="POST" autocomplete="on">
                                	<div class="credit-recharge">
                                    	<div class="step-post-package">
                                        	<h2><?php _e('Choose your package', ET_DOMAIN)?></h2>
                                          	<div class="col-md-4 col-sm-6 col-xs-12">
                                            	<div class="fre-input-field">  
                                                	<select class="fre-chosen-single" name="cdkey_package_name" id="cdkey_package_name" style="display: none;">
                                                    <?php foreach ($packs as $key => $package) { ?>
                                                    	<option value="<?php echo $package->ID ?>">
                                                        	<?php echo $package->post_title;?>(<?php echo $package->et_price;?>)
                                                    	</option>
                                                    <?php } ?>
                                                	</select>
                                            	</div>
                                        	</div>	                                        
                                    	</div>
                                    	<div class="step-post-package">
											<button class="fre-btn" id="generate-cdkey" ><?php _e('Generate cd-key', ET_DOMAIN); ?></button>
											<span style="padding-left: 50px; font-size: 20px">cd-key number is:</span>
											<input type="text" id="cdkey-display" style="height: 40px">
                                    	</div>
                                	</div>
                            	</form>
                        	</div>
                    	</div>
                        <div id="fre-cdkey-display-content" class="fre-cdkey-display-require">
                            <div class="fre-credit-box">
                                <div class="fre-credit-box">
                                    <div class="credit-balance-wrap">
                                        <div class="credit-recharge">
                                            <div class="step-post-package">
                                                <h2 style="text-align: center"><?php _e('cd-key numbers', ET_DOMAIN)?></h2>
                                                <div class="row">
                                                    <form>
                                                        <div class="row">
                                                            <div class="col-md-4 col-sm-6 col-xs-12">
                                                                <div class="fre-input-field">
                                                                    <label class="fre-field-title"><?php _e( 'cdkey type', ET_DOMAIN ); ?></label>
                                                                    <select class="fre-chosen-single" name="cdkey_money_amount" 
                                                                                    style="display: none;">
                                                                        <option value="">all</option>
                                                                            <?php foreach ($packs as $key => $package) { ?>
                                                                        <option value="<?php echo $package->ID ?>">
                                                                          <?php echo $package->post_title;?>(<?php echo $package->et_price; ?>)
                                                                        </option>
                                                                            <?php } ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 col-sm-6 col-xs-12">
                                                                <div class="fre-input-field">
                                                                    <label class="fre-field-title"><?php _e( 'cdkey status', ET_DOMAIN ); ?></label>
                                                                    <select class="fre-chosen-single" name="cdkey_current_status"               style="display: none;">
                                                                        <option value="">all</option>
                                                                        <option value="publish">publish</option>
                                                                        <option value="trash">trash</option>
                                                                        <option value="pending">pending</option>
                                                                    </select>                                                   
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <a class="clear-filter work-project-filter-clear secondary-color"
                                                               href=""><?php _e( 'Clear all filters', ET_DOMAIN ); ?></a>
                                                    </form>                                           
                                                </div>                                                                        
                                            </div>
                                        </div>
                                    </div>
                                </div>                                        
                            </div>
                        
                          	<div class="fre-credit-box">
                            	<div class="credit-balance-wrap">
                              		<div class="fre-table">
                               			<div class="fre-table-head">
                                  			<div class="fre-table-col project-bids-col">cd-key number</div>
    			                            <div class="fre-table-col project-bids-col">status</div>
    			                            <div class="fre-table-col project-budget-col">money type</div>
    			                            <div class="fre-table-col project-action-col">Action</div>
                                		</div>
                                		<div class="cdkey-current-table-rows fre-current-table-rows" style="display: table-row-group;">
    		                                <?php
                                                $cdkey_args = array(
                                                    'post_type'=> 'taobao_cdkey',
                                                    'post_status'=> array('publish', 'pending', 'trash'),
                                                    'suppress_filters' => true,
                                                    'orderby'          => 'date',
                                                    'order'            => 'DESC',
                                                );
                                                $no_result_current = '';
                                                $cdkey_query = new WP_Query($cdkey_args);
                                                $cdkey_post_data = array();

        		                                if( $cdkey_query->have_posts() ) {
                                                    while( $cdkey_query->have_posts() ) {
                                                        $cdkey_query->the_post();
                                                        $cdkey_number = $post->post_title;
                                                        $cdkey_status = $post->post_status;
                                                        $et_price = get_post_meta($post->post_parent, 'et_price', true);
                                                        $cdkey_ID = $post->ID;                                        
                                                        $cdkey_post_data[] = array( 'cdkey_number' => $cdkey_number, 'cdkey_status' => $cdkey_status, 'et_price' => $et_price, 'cdkey_ID' => $cdkey_ID );
                                            ?>
                                            <div class="fre-table-row">
                                                <div class="fre-table-col project-bids-col">
                                                	<?php echo $cdkey_number; ?>              
                                                </div>
                                                <div class="fre-table-col project-bids-col">
                                                    <?php echo $cdkey_status; ?>
                                                </div>
                                                <div class="fre-table-col project-budget-col">
                                                    <?php  echo $et_price; ?>
                                                </div>
                                                <div class="fre-table-col project-action-col">
                                                    <a class="project-action" data-action="delete" data-cdkey-id="<?php echo $cdkey_ID; ?>">
                                                        <?php echo __( 'Delete', ET_DOMAIN ) ?>
                                                    </a>
                                                </div>
                                            </div>
                                			<?php } ?>
    	                                    <script type="data/json" id="cdkey_post_data"><?php echo json_encode( $cdkey_post_data ); ?></script>
                                            <?php } else {
                                                $no_result_current = NO_RESULT;
                                            }
                                            ?>                                          
                                		</div>                            
                              		</div>
                            	</div>
                                <?php
                                    if ( $no_result_current != '' ) {
                                        echo $no_result_current;
                                    }
                                ?>                                                                            
                          	</div>                      
                            <div class="fre-paginations paginations-wrapper">
                                <div class="paginations">
                                <?php
                            	    ae_pagination( $cdkey_query, get_query_var( 'paged' ), 'page' ); ?>
                                </div>
                            </div>
                            <?php
                                wp_reset_postdata();
                                wp_reset_query();
                            ?>
                        </div>
                    </div>                 
                </div>                
            </div>
        </div>
    </div>
</div>