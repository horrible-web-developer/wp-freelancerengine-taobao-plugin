<?php

/**
 * @author Honest Worker
 * @copyright 2018
 * @package AppEngine Payment
 */

/*
Plugin Name: FrE Taobao
Plugin URI: http://enginethemes.com/
Description: Integrates the Taobao payment gateway to your FreelanceEngine site
Version: 1.3.1
Author: EngineThemes
Author URI: http://enginethemes.com/
License: GPLv2
Text Domain: enginetheme
*/

function fre_credit_add_cd_key(){ ?>
    <?php if ( current_user_can( 'manage_options' ) )
    {  ?>
        <li>
            <a href="<?php echo et_get_page_link( "generate-cd-key" ) ?>"><?php _e('generate cd-key', ET_DOMAIN) ?></a>
        </li>
        <li>
            <a href="<?php echo et_get_page_link( "withdraw-money" ) ?>"><?php _e('withdraw money', ET_DOMAIN) ?></a>
        </li>
    <?php } ?>
<?php }

add_action( 'fre_header_before_notify', 'fre_credit_add_cd_key');

function fre_delete_cdkey_modal(){    
    require_once dirname(__FILE__) . '/template/modal-delete-cdkey.php';
    require_once dirname(__FILE__) . '/template/modal-withdraw-confirm.php';
    require_once dirname(__FILE__) . '/template/modal-withdraw-delete.php';   
}
add_action('wp_footer', 'fre_delete_cdkey_modal');

if( !function_exists('fre_credit_add_cd_key_content') ){   
    function fre_credit_add_cd_key_content(){ 
        require_once dirname(__FILE__) . '/taobao-cdkey-list.php'; 
    }
}
add_action( 'fre_credit_cd_key_content', 'fre_credit_add_cd_key_content');

function ae_taobao_require_plugin_file(){
    if(!class_exists('AE_Base')) return;
    require_once dirname(__FILE__) . '/update.php';
    require_once dirname(__FILE__) . '/class-taobao-cdkey.php';
    
    if( !function_exists('FRE_Taobao_Cdkey')) {
        $fre_taobao_cdkey = FRE_Taobao_Cdkey::getInstance();
        $fre_taobao_cdkey->init();
    }
}
add_action('after_setup_theme', 'ae_taobao_require_plugin_file');

//setup admin option
add_filter('ae_admin_menu_pages', 'ae_taobao_add_settings');
function ae_taobao_add_settings($pages) {
    $sections = array();
    $options = AE_Options::get_instance();

    /**
     * ae fields settings
     */
    $sections = array(
        'args' => array(
            'title' => __("Taobao API", ET_DOMAIN) ,
            'id' => 'taobao_field',
            'icon' => 'F',
            'class' => ''
        ) ,

        'groups' => array(
            array(
                'args' => array(
                    'title' => __("Taobao API", ET_DOMAIN) ,
                    'id' => 'taobao-secret-key',
                    'class' => '',
                    'desc' => __('Your Taobao Account Information', ET_DOMAIN) ,
                    'name' => 'taobao'
                ) ,
                'fields' => array(
                    array(
                        'id' => 'taobao_Merchant_SPM',
                        'type' => 'text',
                        'label' => __("Merchant Taobao SPM", ET_DOMAIN) ,
                        'name' => 'taobao_merchant_spm',
                        'class' => ''
                    ),
                    array(
                        'id' => 'taobao_Merchant_ID',
                        'type' => 'text',
                        'label' => __("Merchant Taobao ID", ET_DOMAIN) ,
                        'name' => 'taobao_merchant_id',
                        'class' => ''
                    )
                )
            )
        )
    );

    $temp = new AE_section($sections['args'], $sections['groups'], $options);

    $taobao_setting = new AE_container(array(
        'class' => 'field-settings',
        'id' => 'settings',
    ), $temp, $options);

    $pages[] = array(
        'args' => array(
            'parent_slug' => 'et-overview',
            'page_title' => __('Taobao', ET_DOMAIN) ,
            'menu_title' => __('TAOBAO', ET_DOMAIN) ,
            'cap' => 'administrator',
            'slug' => 'ae-taobao',
            'icon' => '$',
            'icon_class' => 'fa fa-inr',
            'desc' => __("Integrate the TAOBAO payment gateway to your site", ET_DOMAIN)
        ) ,
        'container' => $taobao_setting
    );

    return $pages;
}

add_filter('ae_support_gateway', 'ae_taobao_add_support');
function ae_taobao_add_support($gateways) {
    $gateways['taobao'] = 'Taobao';
    return $gateways;
}

//add button front end
add_action('after_payment_list', 'ae_taobao_render_button');
add_action('after_payment_list_upgrade_account', 'ae_taobao_render_button');
function ae_taobao_render_button() {
    $taobao_key = ae_get_option('taobao');
    if (!$taobao_key['taobao_merchant_spm'] || !$taobao_key['taobao_merchant_id']) return false;
    $taobao_url = "https://item.taobao.com/item.htm"."?spm=".$taobao_key['taobao_merchant_spm']."&id=".$taobao_key['taobao_merchant_id'];
?>
    <li class="panel">
        <span class="title-plan taobao-payment" data-type="taobao">
            <?php _e("Taobao", ET_DOMAIN); ?>
            <span><?php _e("Send your payment to our Taobao account", ET_DOMAIN); ?></span>
        </span>        
        <!-- <a href="#" class="btn btn-submit-price-plan other-payment" data-type="taobao"><?php _e("Select", ET_DOMAIN); ?></a> -->
        <a data-toggle="collapse" data-type="taobao" data-parent="#fre-payment-accordion" href="#fre-payment-taobao" class="btn collapsed other-payment"><?php _e("Select", ET_DOMAIN); ?></a>
        <?php include_once dirname(__FILE__) . '/form-template.php'; ?>
    </li>
<?php
}

add_filter('ae_setup_payment', 'ae_taobao_setup_payment', 10, 3);
function ae_taobao_setup_payment($response, $paymentType, $order) {
    if ($paymentType == 'TAOBAO') {
        echo 'taobao';
    }
}

add_action('ae_payment_script', 'ae_add_taobao_script');
function ae_add_taobao_script() {
    wp_enqueue_script('ae_taobao', plugin_dir_url(__FILE__) . 'assets/taobao.js', array(
        'underscore',
        'backbone',
        'appengine'
    ) , '1.0', true);
    wp_enqueue_style('ae_taobao', plugin_dir_url(__FILE__) . 'assets/taobao.css', array() , '1.0');
}

add_action( 'wp_enqueue_scripts', 'fre_taobao_enqueue_scripts' );
function fre_taobao_enqueue_scripts() {
    wp_enqueue_script('ae_taobao', plugin_dir_url(__FILE__) . 'assets/generatecdkey.js', array(
        'underscore',
        'backbone',
        'appengine'
    ) , '1.0', true);  
    
}