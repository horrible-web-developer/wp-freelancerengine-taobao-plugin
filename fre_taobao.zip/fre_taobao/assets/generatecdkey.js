(function($, Models, Collections, Views) {
    Views.taobaoCdkeyForm = Views.Modal_Box.extend({
        el: $('div#fre-cdkey-content'),       
        events: {
//            'change select#cdkey_money_amount'  : 'cdkeystatus',
            'submit form#cdkey_form'            : 'submitCdkey',
            'click .project-action'             : 'projectActionModal',
 //           'change select#cdkey_current_status': 'cdkeystatus'
        },
        projectActionModal: function (event) {
            event.preventDefault();
            var $target = event.target;
            var view = this;
            if ($target.getAttribute('data-action') == 'delete') {
                if (typeof view.modal_delete_cdkey == 'undefined') {
                    view.modal_delete_cdkey = new Views.Modal_Delete_Cdkey();
                }
                view.modal_delete_cdkey.$('#cdkey-id').val($target.getAttribute('data-cdkey-id'));
                view.modal_delete_cdkey.openModal();
            } 
        },
         
        initialize: function(options) {
            Views.Modal_Box.prototype.initialize.apply(this, arguments);
            // bind event to modal
            _.bindAll(this, 'setupData');
            this.blockUi = new Views.BlockUi();
            // catch event select extend gateway
            AE.pubsub.on('ae:submitPost:extendGateway', this.setupData);
            this.initValidate();
        },
        // callback when user select Paymill, set data and open modal
        setupData: function(data) {
            if (data.paymentType == 'taobao') {
                // this.openModal();
                this.data = data,
                plans = JSON.parse($('#package_plans').html());
                var packages = [];
                _.each(plans, function(element) {
                    if (element.sku == data.packageID) {
                        packages = element;
                    }
                })              
            }
        },
        //setup validate form
        initValidate:function(){
            if(typeof this.validate_ae_cdkey === "undefined"){
                this.validate_ae_cdkey = this.$('form#cdkey_form').validate({
                    rules: {
                    },
                    validClass: "valid", // the classname for a valid element container
                    errorClass: "message", // the classname for the error message for any invalid element
                    errorElement: 'div', // the tagname for the error message append to an invalid element container
                    highlight: function(element, errorClass, validClass) {
                        var required_id = $(element).attr('id');
                        var $container = $(element).closest('div');
                        if (!$container.hasClass('error')) {
                            $container.addClass('error').removeClass(validClass);
                        }
                    },
                    unhighlight: function(element, errorClass, validClass) {
                        var $container = $(element).closest('div.fre-input-field');
                        if ($container.hasClass('error')) {
                            $container.removeClass('error').addClass(validClass);
                        }
                        $container.find('div.message').remove().end().find('i.fa-exclamation-triangle').remove();
                    }
                })    
            }
        },
        
        // catch user event click on generate cd key
        submitCdkey: function(event) {
            event.preventDefault();
            if(this.validate_ae_cdkey.form()){
                var $form = $(event.currentTarget),
                    $container = $form.parents('.step-wrapper'),
                    data = this.data;
                var view = this;
                $target = $(event.currentTarget);
                //                			
                $.ajax({
                    url: ae_globals.ajaxURL,
                    type: 'post',
                    data: {
                        cdkey: $('#cdkey_package_name').val(), 
  //                      moneytype: $('#cdkey_money_amount').val(),
 //                       cdkeystatus: $('#cdkey_current_status').val(),                   
                        action: 'fre_generate_cd_key'
                    },
                    beforeSend: function() {
                        view.blockUi.block($target);
                    },
                    success: function(res) {
                        if( res.success ) {                        	 
                            AE.pubsub.trigger('ae:notification', {
                                msg: res.msg,
                                notice_type: 'success'
                            });
                            
  //                          location.reload();
                            $('#cdkey-display').val(res.final_key);
 //                           $(".fre-current-table-rows").empty();
 //                           $(".fre-current-table-rows").append(res.html);                                                       
                        }
                        else{
                            AE.pubsub.trigger('ae:notification', {
                                msg: res.msg,
                                notice_type: 'error'
                            });
                        }
                        view.blockUi.unblock();
                    }
                });
            }
        },    
        // cdkeystatus: function(event) {
        //     event.preventDefault();
        //     if(this.validate_ae_cdkey.form()){
        //         var $form = $(event.currentTarget),
        //             $container = $form.parents('.step-wrapper'),
        //             data = this.data;
        //         var view = this;
        //         $target = $(event.currentTarget);
        //         //                          
        //         $.ajax({
        //             url: ae_globals.ajaxURL,
        //             type: 'post',
        //             data: {
        //                 moneytype: $('#cdkey_money_amount').val(),
        //                 cdkeystatus: $('#cdkey_current_status').val(),                    
        //                 action: 'fre_generate_cd_key'
        //             },
        //             beforeSend: function() {
        //                 view.blockUi.block($target);
        //             },
        //             success: function(res) {
        //                 if( res.success ) {                             
        //                     AE.pubsub.trigger('ae:notification', {
        //                         msg: res.msg,
        //                         notice_type: 'success'
        //                     });
                           
        //                     $(".fre-current-table-rows").empty();
        //                     $(".fre-current-table-rows").append(res.html);                           
        //                 }
        //                 else{
        //                     AE.pubsub.trigger('ae:notification', {
        //                         msg: res.msg,
        //                         notice_type: 'error'
        //                     });
        //                 }
        //                 view.blockUi.unblock();
        //             }
        //         });
        //     }
        // },
    });
   
    // Modal Delete Project
    Views.Modal_Delete_Cdkey = AE.Views.Modal_Box.extend({
        el: '#modal_delete_cdkey',
        events: {
            'submit form.form-delete-cdkey': 'deletecdkey'
        },
        initialize: function () {
            AE.Views.Modal_Box.prototype.initialize.apply(this, arguments);
            this.blockUi = new Views.BlockUi();
        },
        deletecdkey: function (event) {
            event.preventDefault();
            var view = this,
                $target = $(event.currentTarget),
                cdkey_id = this.$('#cdkey-id').val();
            $.ajax({
                url: ae_globals.ajaxURL,
                type: 'post',
                data: {
                    ID: cdkey_id,
                    action: 'fre_delete_cdkey'
                },
                beforeSend: function () {
                    view.blockUi.block($target);
                },
                success: function (res) {
                    if (res.success) {
                        $target.closest('.info-bidding').remove();
                        AE.pubsub.trigger('ae:notification', {
                            msg: res.msg,
                            notice_type: 'success'
                        });
                    } else {
                        AE.pubsub.trigger('ae:notification', {
                            msg: res.msg,
                            notice_type: 'error'
                        });
                    }
                    //  view.blockUi.unblock();
                    location.reload();
                }
            });
        }
    });

    Views.taobaoDepositForm = Views.Modal_Box.extend({
        el: $('div#fre-payment-taobao'),       
        events: {
            'submit form#taobao_form'     : 'depositTaobao'
        },
        initialize: function(options) {
            Views.Modal_Box.prototype.initialize.apply(this, arguments);
            // bind event to modal
            _.bindAll(this, 'setupData');
            this.blockUi = new Views.BlockUi();
            // catch event select extend gateway
            AE.pubsub.on('ae:submitPost:extendGateway', this.setupData);
            this.initValidate();
        },
        // callback when user select Paymill, set data and open modal
        setupData: function(data) {
            if (data.paymentType == 'taobao') {
                // this.openModal();
                this.data = data,
                plans = JSON.parse($('#package_plans').html());
                var packages = [];
                _.each(plans, function(element) {
                    if (element.sku == data.packageID) {
                        packages = element;
                    }
                })
            }
        },
        //setup validate form
        initValidate:function(){
            if(typeof this.deposit_ae_cdkey === "undefined"){
                this.deposit_ae_cdkey = this.$('form#taobao_form').validate({
                    rules: {
                    },
                    validClass: "valid", // the classname for a valid element container
                    errorClass: "message", // the classname for the error message for any invalid element
                    errorElement: 'div', // the tagname for the error message append to an invalid element container
                    highlight: function(element, errorClass, validClass) {
                        var required_id = $(element).attr('id');
                        var $container = $(element).closest('div');
                        if (!$container.hasClass('error')) {
                            $container.addClass('error').removeClass(validClass);
                        }
                    },
                    unhighlight: function(element, errorClass, validClass) {
                        var $container = $(element).closest('div.fre-input-field');
                        if ($container.hasClass('error')) {
                            $container.removeClass('error').addClass(validClass);
                        }
                        $container.find('div.message').remove().end().find('i.fa-exclamation-triangle').remove();
                    }
                })
            }
        },
        
        // catch user event click on generate cd key
        depositTaobao: function(event) {
            event.preventDefault();
            if(this.deposit_ae_cdkey.form()){
                var $form = $(event.currentTarget),
                    $container = $form.parents('.step-wrapper'),
                    data = this.data;
                var view = this;
                $target = $(event.currentTarget);
                //
                $.ajax({
                    url: ae_globals.ajaxURL,
                    type: 'post',
                    data: {
                        cdkey: $('#taobao_cd_key').val(),
                        action: 'fre_credit_charge_taobao'
                    },
                    beforeSend: function() {
                        view.blockUi.block($target);
                    },
                    success: function(res) {
                        if( res.success ) {                          
                            AE.pubsub.trigger('ae:notification', {
                                msg: res.msg,
                                notice_type: 'success'
                            }); 
                            window.location.href = '/my-credit';                                                    
                        }
                        else{
                            AE.pubsub.trigger('ae:notification', {
                                msg: res.msg,
                                notice_type: 'error'
                            });
                        }
                        view.blockUi.unblock();
                    }
                });
            }
        }
    });

    //cdkey_generator
    var Cdkeycontent = $('#fre-cdkey-display-content');
    var $require_cdkey = $('.fre-cdkey-display-require');
    Models.Cdkey = Backbone.Model.extend();
    Collections.Cdkeys = Backbone.Collection.extend({
        model: Models.Cdkey,
        action: 'fre_cdkey_content',
        initialize: function () {
            this.paged = 1;
        }
    });

    CdkeyItem = Views.PostItem.extend({
        tagName: 'div',
        className: 'fre-table-row',
        template: _.template($('#cdkey-require-js').html())
    });

    ListCdkey = Views.ListPost.extend({
        tagName: 'div',
        itemView: CdkeyItem,
        itemClass: 'fre-table-row'
    });

    var ListCdkeyCollection = new Collections.Cdkeys();
    if ($('#cdkey_post_data').length > 0) {
        var data = JSON.parse($('#cdkey_post_data').html());
        ListCdkeyCollection = new Collections.Cdkeys(data);
    }

    new ListCdkey({
        itemView: CdkeyItem,
        collection: ListCdkeyCollection,
        el: Cdkeycontent.find('.cdkey-current-table-rows')
    });

    new Views.BlockControl({
        el: $require_cdkey,
        collection: ListCdkeyCollection,
        onBeforeFetch: function () {
            var view = this;
            view.blockUi.unblock();
            view.blockUi.block(view.$el);
            if ($require_cdkey.find('.project-no-results').length > 0) {
                $require_cdkey.find('.project-no-results').remove();
            }
        },
        onAfterFetch: function (result, res) {
            if (!res.success || result.length == 0) {
                $require_cdkey.find('.fre-table').after(ae_globals.text_message.no_cdkey);
            }
        },
        onAfterInit: function () {
            var view = this;
            this.$('.clear-filter').on('click', function (event) {
                view.clearFilter(event);
            });
        },
        clearFilter: function (event) {
            
            event.preventDefault();
            var view = this,
            $target = $(event.currentTarget);
            $(view.$el.selector).find('form')[0].reset();
            $(view.$el.selector).find('form select').trigger('chosen:updated');
            view.query['cdkey_money_amount'] = '';
            view.query['cdkey_current_status'] = '';
            
            view.fetch($target);
        }
    });

    // init Taobao form
    $(document).ready(function() {
        new Views.taobaoCdkeyForm();
       new Views.taobaoDepositForm();
    });
})(jQuery, window.AE.Models, window.AE.Collections, window.AE.Views);


