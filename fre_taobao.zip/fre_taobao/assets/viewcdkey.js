
            'submit form#submit_fre_credit_form': 'submitFreCreditPayment'