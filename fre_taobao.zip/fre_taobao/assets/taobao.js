// (function($, Views) {
//     Views.TaobaoForm = Views.Modal_Box.extend({
//         el: $('div#fre-payment-taobao'),
//         events: {
//             'submit form#taobao_form': 'submitTaobao'
//         },
//         initialize: function(options) {
//             Views.Modal_Box.prototype.initialize.apply(this, arguments);
//             // bind event to modal
//             _.bindAll(this, 'setupData');
//             this.blockUi = new Views.BlockUi();
//             // catch event select extend gateway
//             AE.pubsub.on('ae:submitPost:extendGateway', this.setupData);
//             this.initValidate();
//         },
//         // callback when user select Paymill, set data and open modal
//         setupData: function(data) {
//             if (data.paymentType == 'taobao') {
//                 // this.openModal();
//                 this.data = data,
//                 plans = JSON.parse($('#package_plans').html());
//                 var packages = [];
//                 _.each(plans, function(element) {
//                     if (element.sku == data.packageID) {
//                         packages = element;
//                     }
//                 })
//                 // var align = parseInt(ae_taobao.currency.align);
//                 // if (align) {
//                 //     var price = ae_taobao.currency.icon + packages.et_price;
//                 // } else {
//                 //     var price = packages.et_price + ae_taobao.currency.icon;
//                 // }

//                 // this.data.price = packages.et_price;

//                 // //if($('.coupon-price').html() !== '' && $('#coupon_code').val() != '' ) price  =   $('.coupon-price').html();
//                 // this.$el.find('span.plan_name').html(packages.post_title + ' (' + price + ')');
//                 // this.$el.find('span.plan_desc').html(packages.post_content);
//             }
//         },
//         //setup validate form
//         initValidate:function(){
//             if(typeof this.validate_ae_taobao === "undefined"){
//                 this.validate_ae_taobao = this.$('form#taobao_form').validate({
//                     rules: {
//                     },
//                     validClass: "valid", // the classname for a valid element container
//                     errorClass: "message", // the classname for the error message for any invalid element
//                     errorElement: 'div', // the tagname for the error message append to an invalid element container
//                     highlight: function(element, errorClass, validClass) {
//                         var required_id = $(element).attr('id');
//                         var $container = $(element).closest('div');
//                         if (!$container.hasClass('error')) {
//                             $container.addClass('error').removeClass(validClass);
//                         }
//                     },
//                     unhighlight: function(element, errorClass, validClass) {
//                         var $container = $(element).closest('div.fre-input-field');
//                         if ($container.hasClass('error')) {
//                             $container.removeClass('error').addClass(validClass);
//                         }
//                         $container.find('div.message').remove().end().find('i.fa-exclamation-triangle').remove();
//                     }
//                 })    
//             }
//         },
        
//         // catch user event click on pay
//         submitTaobao: function(event) {
//             event.preventDefault();
//             if(this.validate_ae_taobao.form()){
//                 var $form = $(event.currentTarget),
//                     $container = $form.parents('.step-wrapper'),
//                     data = this.data;
//                 var view = this;
//                 $target = $(event.currentTarget);
//                 //                			
//                 $.ajax({
//                     url: ae_globals.ajaxURL,
//                     type: 'post',
//                     data: {
//                         cdkey: $('#taobao_cd_key').val(),
//                         action: 'fre_credit_charge_taobao'
//                     },
//                     beforeSend: function() {
//                         view.blockUi.block($target);
//                     },
//                     success: function(res) {
//                         view.data = res;
//                         if( res.success ) {
//                             AE.pubsub.trigger('ae:notification', {
//                                 msg: res.msg,
//                                 notice_type: 'success'
//                             });
//                             view.data = res.data;

//                             window.location.href = '';
//                         }
//                         else{
//                             AE.pubsub.trigger('ae:notification', {
//                                 msg: res.msg,
//                                 notice_type: 'error'
//                             });
//                         }
//                         view.blockUi.unblock();
//                     }
//                 });
//             }
//         },
//     });
//     // init Payu form
//     $(document).ready(function() {
//         new Views.TaobaoForm();
//     });
// })(jQuery, AE.Views);


